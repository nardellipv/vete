<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Patient extends Model
{
    protected $fillable = [
        'name', 'birthday', 'specie', 'sex', 'weight', 'race', 'castrated', 'pedigree', 'reproductor', 'comment', 'customer_id'
    ];

    public function Customer()
    {
        return $this->belongsTo(Customer::class);
    }

    public function Turn()
    {
        return $this->belongsTo(Turn::class);
    }
}
