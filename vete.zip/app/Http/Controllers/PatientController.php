<?php

namespace App\Http\Controllers;

use App\Patient;
use Illuminate\Http\Request;

class PatientController extends Controller
{
    public function index()
    {
        $patients = Patient::with(['customer'])
            ->get();

        return view('panel.patient._indexPatient', compact('patients'));
    }
}
