<?php

namespace App\Http\Controllers;

use App\Customer;
use Illuminate\Http\Request;

class CustomerController extends Controller
{
    public function index()
    {
        $customers = Customer::all();

        return view('panel.customer._indexCustomer', compact('customers'));
    }

    public function addCustomer()
    {
        return view('panel.customer._addCustomer');
    }
}
