<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreatePatientsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('patients', function (Blueprint $table) {
            $table->id();

            $table->string('name');
            $table->date('birthday');
            $table->string('specie');
            $table->enum('sex', ['MALE', 'FEMALE']);
            $table->string('weight');
            $table->string('race');
            $table->enum('castrated', ['YES', 'NO']);
            $table->enum('pedigree', ['YES', 'NO']);
            $table->enum('reproductor', ['YES', 'NO']);
            $table->mediumText('comment');

            $table->timestamps();


            //relaciones

            $table->foreignId('customer_id')
                ->nullable()
                ->constrained()
                ->onDelete('cascade')
                ->onUpdate('cascade');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('patients');
    }
}
