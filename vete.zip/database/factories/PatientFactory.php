<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Patient;
use Faker\Generator as Faker;

$factory->define(Patient::class, function (Faker $faker) {
    return [
        'name' => $faker->name,
        'birthday' => $faker->date($format = 'Y-m-d'),
        'specie' => $faker->word,
        'sex' => $faker->randomElement($array = array('MALE', 'FEMALE')),
        'weight' => rand(10, 100),
        'race' => $faker->word,
        'castrated' => $faker->randomElement($array = array('YES', 'NO')),
        'pedigree' => $faker->randomElement($array = array('YES', 'NO')),
        'reproductor' => $faker->randomElement($array = array('YES', 'NO')),
        'comment' => $faker->text($maxNbChars = 500),
        'customer_id' => rand(1, 10),
    ];
});
