<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Veterinarian;
use Faker\Generator as Faker;

$factory->define(Veterinarian::class, function (Faker $faker) {
    $title = $faker->unique()->word(10);
    return [
        'name' => $title,
        'address' => $faker->address,
        'city' => $faker->city,
        'postalCode' => rand(100, 10000),
        'phone' => $faker->phoneNumber,
        'user_id' => rand(1, 10),
    ];
});
