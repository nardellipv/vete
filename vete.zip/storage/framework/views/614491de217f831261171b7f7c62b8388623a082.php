

<?php $__env->startSection('breadcrumb', 'Pacientes'); ?>

<?php $__env->startSection('script'); ?>
    <script type="text/javascript"
            src="<?php echo e(asset('styleAdmin/assets/js/plugins/tables/datatables/datatables.min.js')); ?>"></script>
    <script type="text/javascript"
            src="<?php echo e(asset('styleAdmin/assets/js/plugins/forms/selects/select2.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('styleAdmin/assets/js/pages/datatables_basic.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="panel panel-flat">
        <div class="panel-heading">
            <h5 class="panel-title">Listado Pacientes</h5>
            <div class="heading-elements">
                <ul class="icons-list">
                    <li><a data-action="collapse"></a></li>
                </ul>
            </div>
        </div>

        <table class="table datatable-basic">
            <thead>
            <tr>
                <th>Nombre</th>
                <th>Especie</th>
                <th>Raza</th>
                <th>Comentario</th>
                <th>Dueño</th>
                <th>Acción</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $patients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $patient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th><?php echo e($patient->name); ?></th>
                    <th><?php echo e($patient->specie); ?></th>
                    <th><?php echo e($patient->race); ?></th>
                    <th><?php echo e(Str::limit($patient->comment, 100)); ?></th>
                    <th><?php echo e($patient->customer->name); ?></th>
                    <th>
                        <i class="icon-eye"></i>
                        <i class="icon-pencil3"></i>
                        <i class="icon-trash"></i>
                    </th>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.mainAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Webs\vete\resources\views/panel/patient/_indexPatient.blade.php ENDPATH**/ ?>