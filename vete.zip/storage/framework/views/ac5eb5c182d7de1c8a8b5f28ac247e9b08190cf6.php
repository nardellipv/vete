

<?php $__env->startSection('breadcrumb', 'Clientes'); ?>

<?php $__env->startSection('script'); ?>
    <script type="text/javascript" src="<?php echo e(asset('styleAdmin/assets/js/plugins/tables/datatables/datatables.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('styleAdmin/assets/js/plugins/forms/selects/select2.min.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('styleAdmin/assets/js/pages/datatables_basic.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="panel panel-flat">
        <div class="panel-heading">
            <h5 class="panel-title">Listado Clientes</h5>
            <div class="heading-elements">
                <ul class="icons-list">
                    <li><a data-action="collapse"></a></li>
                    <li><a data-action="close"></a></li>
                </ul>
            </div>
        </div>

        <table class="table datatable-basic">
            <thead>
            <tr>
                <th>Nombre y Apellido</th>
                <th>Dirección</th>
                <th>Ciudad</th>
                <th>email</th>
                <th>Teléfono</th>
                <th class="text-center">Actions</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $customer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th><?php echo e($customer->name); ?></th>
                    <th><?php echo e($customer->address); ?></th>
                    <th><?php echo e($customer->city); ?></th>
                    <th><?php echo e($customer->email); ?></th>
                    <th><?php echo e($customer->phone); ?></th>
                    <th>
                        <i class="icon-eye"></i>
                        <i class="icon-pencil3"></i>
                        <i class="icon-trash"></i>
                    </th>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.mainAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Webs\vete\resources\views/panel/customer/_indexCustomer.blade.php ENDPATH**/ ?>