<div class="sidebar sidebar-main sidebar-default">
    <div class="sidebar-content">

        <!-- User menu -->
        <div class="sidebar-user-material">
            <div class="category-content">
                <div class="sidebar-user-material-content">
                    <a href="#"><img src="<?php echo e(asset('styleAdmin/assets/images/placeholder.jpg')); ?>" class="img-circle img-responsive" alt=""></a>
                    <h6>Victoria Baker</h6>
                    <span class="text-size-small">Santa Ana, CA</span>
                </div>

                
            </div>

            
        </div>
        <!-- /user menu -->


        <!-- Main navigation -->
        <div class="sidebar-category sidebar-category-visible">
            <div class="category-content no-padding">
                <ul class="navigation navigation-main navigation-accordion">

                    <!-- Main -->
                    <li class="navigation-header"><span>Menú</span> <i class="icon-menu" title="Main pages"></i></li>
                    <li class="<?php echo e(request()->is('/') ? 'active' : ''); ?>"><a href="<?php echo e(route('home')); ?>"><i class="icon-home4"></i> <span>Dashboard</span></a></li>
                    <li class="<?php echo e(request()->is('clientes') ? 'active' : ''); ?>"><a href="<?php echo e(route('customer.index')); ?>"><i class="icon-user"></i> <span>Clientes</span></a></li>
                    <li class="<?php echo e(request()->is('pacientes') ? 'active' : ''); ?>"><a href="<?php echo e(route('patient.index')); ?>"><i class="icon-heart-broken2"></i> <span>Pacientes</span></a></li>
                    <li class="<?php echo e(request()->is('turnos') ? 'active' : ''); ?>"><a href="<?php echo e(route('turn.index')); ?>"><i class="icon-calendar"></i> <span>Turnos</span></a></li>
                </ul>
            </div>
        </div>
        <!-- /main navigation -->

    </div>
</div><?php /**PATH D:\Webs\vete\resources\views/panel/parts/_menu.blade.php ENDPATH**/ ?>