<?php

use Illuminate\Support\Facades\Route;


Auth::routes();

//Vete ADMIN
Route::middleware(['auth'])->group(function () {
    Route::get('/', 'HomeController@index')->name('home');

    Route::get('/clientes', 'CustomerController@index')->name('customer.index');
    Route::get('/clientes/agregar', 'CustomerController@addCustomer')->name('add.customer');


    Route::get('/pacientes', 'PatientController@index')->name('patient.index');


    Route::get('/turnos', 'TurnController@index')->name('turn.index');
});
//-----------------------
