@extends('layouts.mainAdmin')

@section('content')
    @include('panel.dashboard._widget')
    @include('panel.dashboard._events')
@endsection
