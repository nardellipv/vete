@extends('layouts.mainAdmin')

@section('breadcrumb', 'Pacientes')

@section('script')
    <script type="text/javascript"
            src="{{ asset('styleAdmin/assets/js/plugins/tables/datatables/datatables.min.js') }}"></script>
    <script type="text/javascript"
            src="{{ asset('styleAdmin/assets/js/plugins/forms/selects/select2.min.js')}}"></script>
    <script type="text/javascript" src="{{ asset('styleAdmin/assets/js/pages/datatables_basic.js') }}"></script>
@endsection

@section('content')
    <div class="panel panel-flat">
        <div class="panel-heading">
            <h5 class="panel-title">Listado Pacientes</h5>
            <div class="heading-elements">
                <ul class="icons-list">
                    <li><a data-action="collapse"></a></li>
                </ul>
            </div>
        </div>

        <table class="table datatable-basic">
            <thead>
            <tr>
                <th>Nombre</th>
                <th>Especie</th>
                <th>Raza</th>
                <th>Comentario</th>
                <th>Dueño</th>
                <th>Acción</th>
            </tr>
            </thead>
            <tbody>
            @foreach($patients as $patient)
                <tr>
                    <th>{{ $patient->name }}</th>
                    <th>{{ $patient->specie }}</th>
                    <th>{{ $patient->race }}</th>
                    <th>{{ Str::limit($patient->comment, 100) }}</th>
                    <th>{{ $patient->customer->name }}</th>
                    <th>
                        <i class="icon-eye"></i>
                        <i class="icon-pencil3"></i>
                        <i class="icon-trash"></i>
                    </th>
                </tr>
            @endforeach
            </tbody>
        </table>
    </div>
@endsection